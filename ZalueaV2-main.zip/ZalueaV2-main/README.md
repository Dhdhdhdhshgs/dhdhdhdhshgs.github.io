<p align="center"><img src="https://github.com/TheIcy/ZalueaV2/blob/main/logo.png?raw=true" height="150">
</p>

<h1 align="center">Zaluea V2</h1>

## Games
The games are not included in this repository. However, you can find them [here](https://github.com/caracal-js/gfiles).

## Credits
- [Icy](https://github.com/TheIcy)
- [Ultraviolet](https://github.com/titaniumnetwork-dev/Ultraviolet-Static)
